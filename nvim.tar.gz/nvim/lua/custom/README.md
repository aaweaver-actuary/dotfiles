# Example_config

This can be used as an example custom config for NvChad. Do check the https://github.com/NvChad/nvcommunity
