-- python3 configuration
vim.g.python3_host_prog = "/home/andy/hd-bin/.pyenv/versions/3.11.8/envs/neovim/bin/python3"

