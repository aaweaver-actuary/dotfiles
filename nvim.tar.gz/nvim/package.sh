# put init.lua and lua/ directory into a tar file
# and then compress it with gzip

# create a tar file
tar -cvf nvim.tar init.lua lua/ .stylua.toml

# compress the tar file
gzip -9 -v -k nvim.tar

# remove the tar file
rm nvim.tar
